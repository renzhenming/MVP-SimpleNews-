package com.lauren.simplenews.news.presenter;

/**
 * Description :
 * Author : lauren
 * Email  : lauren.liuling@gmail.com
 * Blog   : http://www.liuling123.com
 * Date   : 15/12/18
 */
public interface NewsPresenter {

    void loadNews(int type, int page);

}
