package com.lauren.simplenews.images.presenter;

/**
 * Description :
 * Author : lauren
 * Email  : lauren.liuling@gmail.com
 * Blog   : http://www.liuling123.com
 * Date   : 15/12/22
 */
public interface ImagePresenter {
    void loadImageList();
}
